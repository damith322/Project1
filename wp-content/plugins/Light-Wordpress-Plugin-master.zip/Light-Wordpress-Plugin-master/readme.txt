=== Light - Automatic Responsive Light Box ===
Contributors: captaintheme, SiamKreative
Donate link: http://captaintheme.com
Tags: light, lightbox, fancybox, fancy box, responsive lightbox, light box
Requires at least: 3.8.0
Tested up to: 4.0.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Automatically add a responsive lightbox to your images.

== Description ==

No options. No configuration. Just install and go!

Demo - http://demos.bryceadams.com/light/

Docs - http://captaintheme.com/docs/item/plugins/light/

== Installation ==

I'll make this as simple as possible.

1. Either download the plugin and upload it or search for it under **Plugins > Add New**. Activate it, too.
2. Done.

== Frequently Asked Questions ==

= It's all going to hell and I need help! =

Please calm down and start a support thread. Also, read the documentation / plugin information again - it's pretty simple.

= Can you add this xx amazing feature? It'll get you so many more downloads! =

Open up a support thread with your brilliant idea and we'll try to make it possible.

= What about foo bar? =

Hmmm…

== Screenshots ==

1. A couple cool dudes in a lightbox.

2. A dog in a gallery.

3. Shark in a bigger gallery.

== Changelog ==

= 1.0.0 =
* The day it started.

== Upgrade Notice ==